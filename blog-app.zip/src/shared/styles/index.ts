import { GlobalStyle } from "./styles";

export default GlobalStyle;
