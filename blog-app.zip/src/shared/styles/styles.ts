import { createGlobalStyle } from "styled-components";

export const GlobalStyle = createGlobalStyle`
  body {
    margin: 0;
    font-family: "Segoe UI", sans-serif;
    background-color: #EBEEF3;
  }
`;
