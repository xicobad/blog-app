import ArticleMeta from "./ArticleMeta";

export default ArticleMeta;
