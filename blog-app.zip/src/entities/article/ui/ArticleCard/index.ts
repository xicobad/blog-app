import ArticleCard from "./ArticleCard";

export default ArticleCard;
