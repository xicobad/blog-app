import styled from "styled-components";

export const PageWrapper = styled.div`
  display: flex;
  justify-content: center;
  background-color: #f5f5f5;
  min-height: 100vh;
`;
